// All displayed quantities come from the same objective model, including fog-of-war-safe map hints.
function sameObjective(a,b){
  return Boolean(a && b && a.kind===b.kind && a.id===b.id && a.key===b.key && a.tier===b.tier);
}

function objectiveControl(pin,selected=sameObjective(objectivePin,pin)){
  const extra=pin.key===undefined?'':' data-key="'+pin.key+'" data-trader="'+esc(pin.trader)+'"';
  const review=selected&&!raid&&!['prep','map'].includes(page)&&resolveObjective()?.materials.length
    ? '<button type="button" class="obj-pin" data-objective="procurement-review">부족품 조달표</button>' : '';
  return '<button type="button" class="obj-pin" data-objective="'+(selected?'clear':'pin')+'" data-kind="'+esc(pin.kind)+
    '" data-id="'+esc(pin.id)+'"'+extra+(pin.tier===undefined?'':' data-tier="'+pin.tier+'"')+
    ' aria-pressed="'+selected+'" '+(writer?'':'disabled')+'>'+commandIcon('pin')+
    (selected?'목표 고정 해제':objectivePin?'이 목표로 교체':'출격 목표로 고정')+'</button>'+review;
}

function objectiveLocationLabel(locations,zone,landmark){
  const matches=locations.filter(loc=>loc.zone===zone && (landmark===undefined||loc.landmark===landmark));
  return matches.length?(matches.some(loc=>!loc.possible)?'목표 지역':'수급 후보'):'';
}

function objectivePlaceName(loc){
  const area=FIELD_ZONES[loc.zone].name;
  return Number.isInteger(loc.landmark)?area+' · '+LANDMARKS[loc.zone][loc.landmark].name:area;
}

function objectivePlaces(locations,context){
  const assigned=locations.filter(loc=>!loc.possible);
  const exact=assigned.length?'<p class="obj-place"><b>목표 지역</b> '+assigned.map(loc=>esc(objectivePlaceName(loc))).join(' / ')+'</p>':'';
  if(context!=='map')return exact;
  const zone=commandZoneSelection();
  const possible=locations.filter(loc=>loc.possible && loc.zone===zone);
  if(!possible.length)return exact;
  const byItem=new Map();
  for(const site of possible){
    const name=LANDMARKS[zone][site.landmark].name;
    for(const item of site.items||[]){
      if(!byItem.has(item))byItem.set(item,new Set());
      byItem.get(item).add(name);
    }
  }
  const rows=Array.from(byItem,([item,names])=>'<li><b>'+esc(GOODS[item][0])+'</b> '+Array.from(names,esc).join(' · ')+'</li>');
  return exact+'<details class="obj-sources"><summary>'+esc(FIELD_ZONES[zone].name)+' 수급 후보 '+possible.length+
    '곳</summary><ul>'+rows.join('')+'</ul></details>';
}

function objectiveMaterialRow(m,facility){
  const flags=' data-objective-material="'+esc(m.id)+'" data-required="'+m.required+'" data-owned="'+m.owned+
    '" data-usable="'+m.usable+'" data-field="'+m.field+'" data-missing="'+m.missing+'"';
  const inventory=[['창고·입고 대기',m.loose],['보관함',m.cases],['준비 가방',m.bag],['착용 중',m.worn]]
    .filter(([,qty])=>qty>0).map(([where,qty])=>where+' '+qty).join(' · ');
  const recovery=m.construction!==undefined;
  const allocation=recovery?'<small class="obj-inventory">'+[m.aid?'구호 납품 '+m.aid+'개':'',m.construction?'시설 건설 '+m.construction+'개':''].filter(Boolean).join(' · ')+'</small>':'';
  const atRisk=m.field>0?'<span class="obj-risk">현장 가방 '+m.field+'개 · 생환 후 부족 '+Math.max(0,m.missing-m.field)+'개</span>':'';
  const relocate=(facility || m.construction) && m.missing>0 && (m.bag||m.cases)?'<span class="obj-rule">건설에 쓸 물품은 창고로 옮기세요.</span>':'';
  return '<li class="obj-material"'+flags+'><div class="obj-mat-heading"><strong>'+esc(GOODS[m.id][0])+'</strong>'+
    '<span class="'+(m.missing?'obj-short':'obj-ready')+'">'+(m.missing?'부족 '+m.missing:'부족 0 · 확보')+'</span></div>'+
    '<div class="obj-quantities"><span>필요 <b>'+m.required+'</b></span><span>보유 <b>'+m.owned+'</b></span>'+
    '<span>'+ (recovery?'지금 충당 가능':facility?'건설용 창고 재고':'납품용 보유량')+' <b>'+m.usable+'</b></span></div>'+
    allocation+(inventory?'<small class="obj-inventory">'+inventory+'</small>':'')+atRisk+(m.fieldWorn?'<span class="obj-rule">현장 장착 '+m.fieldWorn+'개 · 생환 후 해제하여 사용</span>':'')+relocate+(m.worn&&m.missing?'<span class="obj-rule">착용 장비나 장착 모듈을 해제해 창고에 넣으세요.</span>':'')+'</li>';
}

function objectiveGoalRows(goals){
  if(!goals.length)return '';
  return '<ul class="obj-goals">'+goals.map(g=>{
    const preview=Number.isFinite(g.projected)&&g.projected>g.value?'<small>생환 시 '+g.projected+' / '+g.target+'</small>':'';
    return '<li><span>'+esc(g.label)+'</span><b>'+g.value.toLocaleString('ko-KR')+' / '+g.target.toLocaleString('ko-KR')+'</b>'+preview+'</li>';
  }).join('')+'</ul>';
}

function objectiveOpenLabel(pin,settle){
  if(pin.kind==='finale')return settle?'복귀 후 종결 작전 열기':'종결 작전 열기';
  if(pin.kind==='campaign')return settle?'복귀 후 복구 캠페인 열기':'복구 캠페인 열기';
  if(pin.kind==='facility')return settle?'복귀 후 시설 열기':'시설 열기';
  if(pin.kind==='order')return settle?'복귀 후 벙커 의뢰 열기':'벙커 의뢰 열기';
  const trader=findMarketTrader(pin.trader || CONTRACT_BY_ID.get(pin.id)?.trader);
  return (settle?'복귀 후 ':'')+(trader?trader.name+' 의뢰 열기':'상인 의뢰 열기');
}

let expandedFieldObjective=null;
inside.addEventListener('toggle',event=>{
  const details=event.target;
  if(details?.dataset?.objectiveDetails!=='field'||!details.isConnected)return;
  expandedFieldObjective=details.open?objectivePin:null;
},true);

function objectivePanel(context,objective=resolveObjective()){
  if(!objective){
    if(context!=='result'||!lastSummary?.completedObjectiveOrder)return '';
    const order=ORDERS.find(entry=>entry.id===lastSummary.completedObjectiveOrder && career.done.includes(entry.id));
    if(!order)return '';
    return '<section class="obj-panel" data-objective-panel="result" aria-label="고정 목표 결과">'+
      '<p class="obj-label">'+commandIcon('pin')+'고정 목표 정산</p><h2>'+esc(order.title)+'</h2><p class="obj-ready">완료 · 보상 지급</p></section>';
  }
  const o=objective,facility=o.source.kind==='facility';
  const materialList=o.materials.length?'<ul class="obj-materials" aria-label="필요 물품">'+o.materials.map(m=>objectiveMaterialRow(m,facility)).join('')+'</ul>':'';
  const showOpen=!raid||context==='result';
  const actions='<div class="obj-actions">'+(showOpen?'<button type="button" data-objective="open" '+(raid&&!writer?'disabled':'')+'>'+
    esc(objectiveOpenLabel(o.source,context==='result'))+'</button>':'')+
    (context==='prep'||context==='field'?'<button type="button" data-page="map">작전 지도</button>':'')+
    objectiveControl(o.source,true)+'</div>';
  const procurement=!raid&&o.materials.length&&['prep','map'].includes(context)?procurementPanel():'';
  let body=objectivePlaces(o.locations,context)+objectiveGoalRows(o.goals)+materialList+procurement+actions;
  if(facility&&(context==='field'||context==='loot')){
    const filled=o.materials.filter(m=>m.missing===0).length;
    body='<details class="obj-field-details" data-objective-details="field" '+(sameObjective(expandedFieldObjective,o.source)?'open':'')+
      '><summary>건설 자재 '+filled+' / '+o.materials.length+'종 확보 · 상세 보기</summary>'+body+'</details>';
  }
  return '<section class="obj-panel" data-objective-panel="'+context+'" aria-label="고정한 출격 목표">'+
    '<header><div><p class="obj-label">'+commandIcon('pin')+'고정한 출격 목표 · '+esc(o.kindLabel)+'</p><h2>'+esc(o.title)+'</h2></div>'+
    '<span class="obj-status">'+esc(o.status)+'</span></header>'+body+'</section>';
}

function objectiveLootHint(unit,objective){
  if(!unit?.revealed||!objective)return '';
  const m=objective.materials.find(row=>row.id===unit.g);
  return m?' · 목표 물품 · 필요 '+m.required+' · 보유 '+m.owned+' · 부족 '+m.missing:'';
}

function objectiveLootBadge(unit,objective=resolveObjective()){
  if(!unit?.revealed||!objective?.materials.some(m=>m.id===unit.g))return '';
  return '<i class="obj-tile-mark" aria-hidden="true" title="목표 물품">'+commandIcon('pin')+'</i>';
}

function objectiveSelectedItem(unit,objective=resolveObjective()){
  if(!unit?.revealed||!objective)return '';
  const material=objective.materials.find(m=>m.id===unit.g);
  if(!material)return '';
  return '<section class="obj-item" data-objective-item="'+esc(unit.g)+'"><h3>'+commandIcon('pin')+'목표 물품</h3>'+
    '<ul class="obj-materials">'+objectiveMaterialRow(material,objective.source.kind==='facility')+'</ul></section>';
}

function openObjectiveSource(){
  const active=resolveObjective();
  if(!active)return;
  const pin=active.source;
  if(raid){
    if(!field?.result||!writer)return;
    handleRaidAction('ack');
    if(raid)return;
  }
  if(pin.kind==='campaign'||pin.kind==='finale'){navigatePage('campaign');return;}
  if(pin.kind==='facility'){openBunkerFacility(pin.id,pin.tier);return;}
  if(pin.kind==='order'){
    bunkerOrderFilter='all';bunkerOrderSelected=pin.id;
    navigatePage('orders');return;
  }
  const trader=pin.trader || CONTRACT_BY_ID.get(pin.id)?.trader;
  if(!marketSelectTrader(trader))return;
  setTraderQuestMode(pin.kind==='contract'?'standing':pin.kind);
  if(pin.kind==='contract'){
    const q=CONTRACT_BY_ID.get(pin.id);
    contractPanel.trader=trader;contractPanel.quest=q.id;contractPanel.tier=q.tier;
  }
  navigatePage('traderQuests');
  const card=pin.kind==='contract'?document.querySelector('.cq-detail'):
    Array.from(document.querySelectorAll('.rc-card')).find(el=>el.dataset.offer===pin.id);
  card?.scrollIntoView?.({block:'nearest'});
  card?.focus?.({preventScroll:true});
}

function handleObjectiveUI(d){
  if(d.objective.startsWith('procurement-')){handleProcurementUI(d);return;}
  if(d.objective==='open'){openObjectiveSource();return;}
  if(!writer||!['pin','clear'].includes(d.objective))return;
  const pin={kind:d.kind,id:d.id};
  if(d.key!==undefined){pin.key=Number(d.key);pin.trader=d.trader;}
  if(d.tier!==undefined)pin.tier=Number(d.tier);
  const clear=d.objective==='clear';
  if(clear&&!sameObjective(objectivePin,pin))return;
  const keyboard=document.activeElement?.matches?.(':focus-visible');
  const saved=setObjectivePin(clear?null:pin);
  renderKeep();
  const announcer=$('#announce');
  if(announcer)announcer.textContent=saved?(clear?'출격 목표 고정을 해제했습니다.':'출격 목표를 고정했습니다.'):'목표를 저장하지 못했습니다. 현재 진행 상태를 확인하세요.';
  if(keyboard){
    const source=Array.from(document.querySelectorAll('button[data-objective]')).find(el=>el.dataset.id===pin.id&&el.dataset.kind===pin.kind);
    (source||$('.content'))?.focus?.({preventScroll:true});
  }
}
