// A raid carries its exit assignment, contact and timers until settlement.
const ESCAPE_CHANCE = 0.65;
const CONTACTS = [
  {name:'외곽 정찰 드론', hp:36, power:12},
  {name:'검문소 경비 기체', hp:52, power:17},
  {name:'창고 방호 기체', hp:68, power:23}
];
// A container item keeps its zone-box-slot UID while it is carried in the raid.
// Warehouse and loadout entries receive new UIDs, including after a successful return.
function matchesOrderRecovery(unit,{zone,landmark,item}){
  if(unit.g!==item)return false;
  const parts=/^(0|[1-9]\d*)-(0|[1-9]\d*)-(?:0|[1-9]\d*)$/.exec(unit.uid);
  if(!parts || Number(parts[1])!==zone)return false;
  const box=Number(parts[2]);
  return LANDMARKS[zone][landmark].boxes.includes(box)&&field.found[zone].includes(box);
}
function countOrderRecovery(order){
  return field.bag.filter(unit=>matchesOrderRecovery(unit,order.recovery)).length;
}
const ORDERS = [
  {id:'scout', issuer:'벙커 관제실', title:'외곽 통신선 조사', text:'한 레이드에서 서로 다른 두 지역을 방문하고 정상 탈출하세요.', cr:20000, xp:80,
    goal:'서로 다른 지역 방문', target:2, progress:()=>new Set(field.visited||[raid.zone]).size},
  {id:'stores', issuer:'보급 담당관', title:'보급품 위치 확인', text:'한 레이드에서 컨테이너 두 개를 끝까지 수색하고 정상 탈출하세요.', cr:32000, xp:120,
    goal:'컨테이너 수색 완료', target:2, progress:()=>Object.values(field.boxes).filter(box=>box.complete).length},
  {id:'signals', issuer:'현장 정비반', title:'고장 난 경비망', text:'한 레이드에서 경비 기체 한 대를 무력화하고 정상 탈출하세요.', cr:42000, xp:150,
    goal:'경비 기체 무력화', target:1, progress:()=>field.victories||0},
  {id:'tower-wire', issuer:'벙커 전력반', title:'단선 구간 표본 회수',
    text:'송전탑 선로를 수리하려면 현장 전선의 규격이 필요합니다. 벙커 외곽의 송전탑 점검소에서 전력반 자재 상자 또는 점검실 컴퓨터를 수색하세요. 이번 출격에서 그곳에서 찾은 전선 묶음 한 개를 가방에 넣고 정상 탈출하면 검사비를 지급합니다. 검사한 전선은 창고에 보관됩니다.',
    cr:36000, xp:130, goal:'송전탑 점검소에서 찾은 전선 묶음 휴대', target:1,
    recovery:{zone:0,landmark:5,item:'wire'}, progress:countOrderRecovery}
];
let career,orderFeedback='',raidAckFeedback='';
function readCareer(raw={}) {
  orderFeedback='';raidAckFeedback='';
  const number = n => Number.isSafeInteger(n) && n>=0 ? n : 0;
  const done = ORDERS.filter(q=>raw?.done?.includes(q.id)).map(q=>q.id);
  career = {xp:number(raw?.xp), sorties:number(raw?.sorties), returns:number(raw?.returns),
    victories:number(raw?.victories), victoriesFrom:Number.isSafeInteger(raw?.victoriesFrom)?number(raw.victoriesFrom):number(raw?.sorties),
    done, order:ORDERS.some(q=>q.id===raw?.order && !done.includes(q.id))?raw.order:null,
    history:Array.isArray(raw?.history)?raw.history.slice(0,12):[]};
}
function playerLevel(){return 1+Math.floor(Math.sqrt(career.xp/150))}
function shuffleExits(){
  const pool=EXITS.filter(e=>e.id!=='b04').map(e=>e.id);
  for(let i=pool.length-1;i>0;i--){const k=Math.floor(Math.random()*(i+1));[pool[i],pool[k]]=[pool[k],pool[i]]}
  return ['b04',...pool.slice(0,1+Math.floor(Math.random()*3))];
}
function prepareSortie(legacy=false){
  if(!raid)return;
  if(!Array.isArray(field.exits))field.exits=legacy?EXITS.map(e=>e.id):shuffleExits();
  if(!Number.isInteger(field.hp))field.hp=100;
  if(!Number.isInteger(field.steps))field.steps=0;
  if(!Number.isInteger(field.nextContact))field.nextContact=3+Math.floor(Math.random()*2);
  if(!Number.isInteger(field.victories))field.victories=0;
}
function actionDuration(type,ms,at=Date.now(),region=raid?.zone??zone){
  const kit=raid && !field.result ? field : equipmentState;
  const base=adjustHideoutActionMs(type,ms);
  const gearFactor=(type==='scan' ? gearScanFactor(kit) : 1) * kitModuleTimeFactor(type,kit);
  const duration=injuryDuration(type,Math.round(base*gearFactor));
  return type==='scan' ? Math.round(duration*regionalWeather(region,at).scanFactor) : duration;
}
function durationLabel(type,ms){return (actionDuration(type,ms)/1000).toLocaleString('ko-KR')+'초'}
const VEHICLE_EXIT_FEE = 15000;
function vehicleFareBalance(carried = cashSum(field.bag)) {
  return (wallet - VEHICLE_EXIT_FEE) + carried;
}
function pointStatus(e, time, starting){
  if(!raid||field.result||time>=raid.endsAt)return '레이드 종료';
  if(field.journey)return '이동 중';
  if(!field.exits?.includes(e.id))return '미배정 탈출구';
  if(e.rule==='pay'&&vehicleFareBalance()<0)return '15,000 CR 필요';
  if(e.rule==='empty'&&hasRaidBackpack())return '배낭을 벗어야 합니다';
  if(e.rule==='card'&&!raidHasItem('keycard'))return '통제구역 키카드 필요';
  if(e.rule==='radio'&&!raidHasItem('radio'))return '무전기 필요';
  if(e.rule==='radio'&&!workingRaidRadio())return '작동하는 무전기 필요';
  const end=starting?time+e.sec*1000:time;
  if(e.rule==='train'){
    const [opens,closes]=trainWindow();
    if(time<opens)return '열차 도착 대기';
    if(end>=closes)return '열차 탑승 마감';
  }
  return end>=raid.endsAt?'남은 레이드 시간 부족':'';
}
function exhaustionDamage(energy,water){
  return energy>0&&water>0?0:8;
}
function sufferExhaustion(at){
  const damage=exhaustionDamage(field.energy,field.water);
  if(!damage)return false;
  field.hp=Math.max(0,field.hp-damage);
  if(field.hp===0){finishRaid('kia',at);return true}
  logField('탈진으로 체력 '+damage+' 감소. 식량이나 물을 사용하세요.');
  return false;
}
function encounterAfter(a){
  if(field.result || !['scan','move'].includes(a.type))return;
  field.steps++;
  if(sufferExhaustion(a.end))return;
  if(field.steps<field.nextContact)return;
  const spec=CONTACTS[raid.zone];
  field.contact={zone:raid.zone,hp:spec.hp};
  field.nextContact=field.steps+3+Math.floor(Math.random()*3);
  field.open=null;
  picked=null;
  logField(spec.name+' 접근. 대응을 선택하세요.');
}
function resolveEncounter(a){
  const c=field.contact;
  field.action=null;
  if(!c)return;
  const spec=CONTACTS[c.zone];
  const strike=a.type==='engage';
  if(!strike&&(a.escaped??(Math.random()<ESCAPE_CHANCE))){
    field.contact=null;
    logField(spec.name+'에게서 도주 성공.');
    if(field.journey)resumeJourney(a.end);
    return;
  }
  if(strike){
    settlementNeedsCommit=true;
    if(a.legacyGear)delete field.legacyEngagement;
    if(!payEngagement(a)){logField('장비 상태가 달라져 교전을 중단했습니다.');return;}
    const bonus=a.strike?.slot==='secondary'?2:gearAttackBonus();
    const hit=14+Math.min(10,playerLevel()-1)+bonus+(a.strike?.attackRoll??Math.floor(Math.random()*7));
    c.hp=Math.max(0,c.hp-hit);
    if(!c.hp){
      field.contact=null;
      field.victories++;
      recordRecurringKill(c.zone,a.end);
      logField(spec.name+' 무력화.');
      if(field.journey)resumeJourney(a.end);
      return;
    }
    delete c.escapeDamage;
  }
  const damage=Math.max(1,(strike?spec.power:Math.ceil(spec.power*0.55))+(a.strike?.defenseRoll??Math.floor(Math.random()*5))-gearDefenseBonus());
  if(!a.legacyGear)for(const slot of ['armor','head','eyes'])wearEquipment(slot);
  if(!strike)c.escapeDamage=damage;
  const lost=Math.min(field.hp,damage);
  field.hp=Math.max(0,field.hp-damage);
  recordContactInjury(a.end,lost);
  logField((strike?'교전 지속':'도주 실패')+' · 체력 '+damage+' 감소.');
  if(!field.hp)finishRaid('kia',a.end);
}
function contactPage(){
  const c=field.contact, spec=CONTACTS[c.zone], busy=!!field.action;
  return head('FIELD / CONTACT',spec.name,field.journey?'이동 도중 적과 마주쳤습니다.':'현장 신호가 끊겼습니다. 행동을 선택하세요.')+
    weatherBrief('field',raid.zone)+journeyProgress()+injuryFieldBrief()+
    '<section class="panel combat"><div class="combat-vitals"><div>내 체력 <strong>'+field.hp+' / 100</strong></div><div>상대 내구도 <strong>'+c.hp+' / '+spec.hp+'</strong></div></div>'+
    '<p>도주에 성공하면 피해 없이 벗어납니다. 실패하면 피해를 받고, 다시 도주하거나 교전할 수 있습니다.</p>'+
    (c.escapeDamage?'<p class="evade-result" role="status">도주 실패 · 체력 '+Number(c.escapeDamage)+' 감소</p>':'')+
    (notice?'<p role="status">'+esc(notice)+'</p>':'')+actionMarkup()+'<div class="contact-buttons">'+gearEngageButtons(busy)+'<button data-field="evade" '+(busy?'disabled':'')+'>도주 · '+durationLabel('evade',2000)+' · 성공 '+Math.round(ESCAPE_CHANCE*100)+'%</button><button data-page="inventory">장비 · 응급 처치</button></div></section>'+
    objectivePanel('field')+'<section class="field-section"><h2>현장 기록</h2>'+field.log.slice(0,4).map(l=>'<p>'+esc(l)+'</p>').join('')+'</section>';
}

const ENDINGS={
  success:['SURVIVED','탈출 성공'], quick:['RUN THROUGH','조기 탈출'], kia:['KIA','전투 불능'], expired:['MIA','시간 초과'],abandoned:['LEFT','레이드 포기']
};
function qualifiesNormalExtraction(elapsedMs, searched, victories) {
  return elapsedMs >= 7 * 60000 || searched >= 2 || victories >= 1;
}
function reconcileEnd(result,at,exit=null){
  if(!raid || field.result && (field.result!=='expired'||lastSummary?.raidId===raid.startedAt))return;
  if(injuryState?.raidId===raid.startedAt)at=Math.max(at,injuryState.events.at(-1)?.at||0);
  if(survivorState.active?.raidId===raid.startedAt){
    at=Math.max(at,survivorLastAction(survivorState.active),field.survivorScavenge?.at||0);
  }
  const goods=field.bag.map(o=>o.g).filter(id=>id!=='cr_notes'&&Object.hasOwn(GOODS,id));
  const carriedCash=typeof cashSum==='function'?cashSum(field.bag):0;
  const returned=result==='success';
  const elapsed=Math.max(0,Math.min(RAID_DURATION_MS,at-raid.startedAt));
  const searched=Object.values(field.boxes).filter(b=>b.complete).length;
  const visited=(field.visited||[raid.zone]).length;
  const victories=field.victories||0;
  const quick=returned && !qualifiesNormalExtraction(elapsed,searched,victories);
  const rating=quick?'quick':result;
  const contractUpdates=settleTraderContracts(rating);
  const campaignStage=settleCampaignReturn(rating,raid.startedAt);
  const finaleAttempt=finaleState.attempt;
  const finaleReply=settleFinaleReturn(rating,raid.startedAt);
  const cost=returned&&exit?.rule==='pay'?VEHICLE_EXIT_FEE:0;
  const earned=returned?(quick?25:100+searched*25+Math.max(0,visited-1)*20+victories*50):0;
  let commission=0, missionXp=0, orderName='';
  const order=ORDERS.find(q=>q.id===career.order);
  if(returned&&!quick&&order&&Number.isSafeInteger((wallet-cost)+carriedCash+order.cr)&&order.progress(order)>=order.target){
    commission=order.cr;missionXp=order.xp;orderName=order.title;
    career.done.push(order.id);career.order=null;
  }
  if(returned && exit?.rule==='radio')recordGearUse(workingRaidRadio(),0,1);
  const gearReport=sortieGearReport(returned);
  const walletBeforeSettlement=wallet;
  if(returned){
    for(const unit of field.bag){
      if(unit.g==='rl_bp_dressing')receiveWardSheet(unit.uid);
      else if(unit.g!=='cr_notes')addStashGoods(unit.g,1,unit.gear);
    }
    wallet=(wallet-cost)+carriedCash+commission;
    career.returns++;
  }
  const worn=finishEquipmentRaid(returned);
  career.sorties++;career.xp+=earned+missionXp;career.victories+=victories;
  const summary={raidId:raid.startedAt,result,rating,exit:exit?.name||null,elapsed,goods,cost,visited,searched,victories,
    worn,earned,commission,missionXp,orderName,contractUpdates,gearReport,...(carriedCash?{carriedCash}:{})};
  settleInjuries(summary);
  delete field.gearUsage;delete field.legacyEngagement;
  const survivorSortie=survivorState.active?.raidId===raid.startedAt;
  if(survivorSortie)finishSurvivorRaid(raid.startedAt);
  settlementNeedsCommit=true;
  if (campaignStage) summary.campaignStage=campaignStage;
  if (finaleAttempt?.raidId===raid.startedAt) summary.finaleAttempt={zones:[...finaleAttempt.confirmed]};
  if (finaleReply) summary.finaleReply=true;
  if (orderName && objectivePin?.kind === 'order' && objectivePin.id === order.id) {
    summary.completedObjectiveOrder = order.id;
  }
  lastSummary=summary;
  career.history.unshift({
    rating, elapsed, xp:earned+missionXp, exit:summary.exit, at, zone:raid.zone,
    visited, searched, victories, carriedCash, cash:wallet-walletBeforeSettlement, goods:returned?goods.slice():[],
    commission, missionXp, orderName, cost
  });
  career.history.length=Math.min(12,career.history.length);
  field.result=result;field.journey=null;field.bag=[];field.action=null;field.contact=null;field.open=null;picked=null;dragged=null;exitNotice='';
  logField(ENDINGS[rating][1]+'. 정산 완료.');
}
function resultPage(){
  const r=field.result?lastSummary:null;
  const status=raidAckFeedback||(!writer?'다른 탭에서 플레이 중입니다. 해당 탭에서 벙커로 복귀하세요.':'');
  const ack=(status?'<p class="exit-warn" role="status">'+esc(status)+'</p>':'')+
    '<button class="primary" data-raid="ack"'+(writer?'':' disabled')+'>벙커로 복귀</button>';
  if(!r)return head('FIELD / ENDED','레이드 종료','정산 기록이 없습니다.')+ack;
  const returned=r.result==='success',rating=r.rating||r.result;
  const [code,label]=ENDINGS[rating]||ENDINGS.expired;
  const counts={};
  for(const id of r.goods||[])if(Object.hasOwn(GOODS,id))counts[id]=(counts[id]||0)+1;
  return head('AFTER ACTION REPORT',label,returned?'휴대 물품을 벙커로 회수했습니다.':'이번 출격의 휴대 물품과 착용 장비를 잃었습니다.')+
    huntSummary('result')+objectivePanel('result')+campaignSettlementNote(r)+finaleSettlementNote(r)+'<section class="panel result-panel"><h2 class="'+(returned?'exit-ok':'exit-warn')+'">'+code+'</h2>'+
    (rating==='quick'?'<p>7분 전에 귀환했고 수색 완료 2회와 교전 승리 1회 중 어느 조건도 채우지 않아 조기 탈출로 기록됐습니다. 물품은 보존되며 기본 경험치 25를 받습니다.</p>':'')+
    '<div class="field-metrics"><div>경과 시간<b>'+formatRaid(r.elapsed)+'</b></div><div>방문 지역<b>'+r.visited+'</b></div><div>수색 완료<b>'+r.searched+'</b></div><div>교전 승리<b>'+(r.victories||0)+'</b></div></div>'+
    '<p>'+esc(r.exit||'탈출구 미도달')+' · 탈출 비용 '+money(r.cost||0)+' · 경험치 +'+((r.earned||0)+(r.missionXp||0))+'</p>'+
    (r.carriedCash?'<p>휴대 지폐 '+(returned?'회수':'손실')+' · '+money(r.carriedCash)+'</p>':'')+
    (returned && counts.rl_bp_dressing?'<p>작업지침을 회수했습니다. 의무실에서 원본을 등록하세요.'+(hideout.wardManual.waiting.length?' 창고 공간이 부족한 원본은 의무실 인계칸에 있습니다.':'')+'</p>':'')+
    (r.orderName?'<p class="exit-ok">'+esc(r.orderName)+' 의뢰 완료 · '+money(r.commission)+'</p>':'')+
    '<h3>'+(returned?'회수한 물품':'잃은 물품')+'</h3><div class="db-list">'+(Object.entries(counts).map(([id,n])=>'<div class="stash-row">'+ico(GOODS[id][4])+'<span>'+GOODS[id][0]+'</span><b>×'+n+'</b></div>').join('')||'<p>휴대 물품 없음</p>')+'</div>'+equipmentSummary(r)+gearSettlementMarkup(r)+injurySummaryMarkup(r)+contractResultPanel(r.contractUpdates)+
    ack+'</section>';
}
function journalPage(){
  const lv=playerLevel();
  return head('03 / FIELD JOURNAL','작전 기록','대원 성장과 벙커에서 수신한 의뢰')+
    '<section class="panel"><h2>대원 Lv.'+lv+'</h2><p>'+career.xp+' XP · 다음 레벨 '+(150*lv*lv)+' XP · 출격 '+career.sorties+'회 · 귀환 '+career.returns+'회</p><p>레벨마다 교전 피해가 1 증가합니다. 최대 보너스는 10입니다.</p></section>'+
    '<section class="field-section"><h2>벙커 의뢰</h2><p>출격 전에 한 건을 수락하세요. 정상 탈출 시 조건을 확인하고 보상을 지급합니다.</p>'+orderStatus()+'<div class="orders">'+ORDERS.map(q=>{
      const done=career.done.includes(q.id),active=career.order===q.id;
      return '<article class="panel"><small>'+q.issuer+'</small><h3>'+q.title+'</h3><p>'+q.text+'</p><p>'+money(q.cr)+' · '+q.xp+' XP</p><button data-order="'+q.id+'" '+(!writer||done||raid||(!active&&career.order)?'disabled':'')+'>'+(done?'완료':active?'수락 취소':'의뢰 수락')+'</button></article>';
    }).join('')+'</div></section><section class="field-section"><h2>최근 출격</h2>'+
    (career.history.map(row=>'<div class="sortie-row"><b>'+esc((ENDINGS[row.rating]||ENDINGS.expired)[1])+'</b><span>'+esc(row.exit||'귀환 실패')+' · '+formatRaid(row.elapsed)+' · '+Number(row.xp)+' XP</span></div>').join('')||'<p>첫 출격을 마치면 이곳에 결과가 기록됩니다.</p>')+'</section>';
}
function orderStatus(){
  const status=orderFeedback||(!writer?'다른 탭에서 플레이 중입니다. 해당 탭에서 의뢰를 변경하세요.':'');
  return status?'<p role="status" class="bu-minor">'+esc(status)+'</p>':'';
}
function changeOrder(id){
  if(!writer)return;
  const owner=career;
  reconcile();
  if(owner!==career){
    orderFeedback='의뢰 기록을 다시 불러왔습니다. 현재 상태를 확인하세요.';
    renderKeep();return;
  }
  if(raid||!ORDERS.some(q=>q.id===id)||career.done.includes(id)||(career.order&&career.order!==id))return;
  const previous=career.order;
  career.order=previous===id?null:id;
  orderFeedback='';
  if(!writeSession()){
    if(career===owner){
      career.order=previous;
      orderFeedback='의뢰 변경을 저장하지 못했습니다. 다시 시도하세요.';
    }else orderFeedback='다른 탭의 최신 의뢰 기록을 불러왔습니다.';
  }
  renderKeep();
}
